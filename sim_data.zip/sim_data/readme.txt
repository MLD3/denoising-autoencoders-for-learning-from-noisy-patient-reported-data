This directory contains all simulated data used in analyses. 

adultXX-0.pkl is the main dataset, while adultXX-XALT.pkl represents the alternate noise functions.

Data was generated as described in the paper, using this implementation of the UVa/Padova Simulator***:

https://github.com/jxx123/simglucose

The 10 adult subjects are included.

Each entry in the pkl file represents a day of data, with these five variables as columns: glucose, bolus insulin, carbohydrates (true values), basal insulin, carbohydrates (noisy values). Bolus values are calculated with noisy carb values.

The noise functions used are:


adultXX-0.pkl: Y=X*(.75+np.random.normal(0,.5)) [main dataset]

adultXX-1ALT.pkl: Y=X*(1+np.random.normal(0,.75))
		
adultXX-2ALT.pkl: Y=X*(1.6*np.random.uniform())
			
adultXX-3ALT.pkl: Y=X+np.random.normal(-30,50)

adultXX-4ALT.pkl: Y=X+np.random.normal(0,40)

adultXX-5ALT.pkl: Y=X+40-100*np.random.uniform()

adultXX-6ALT.pkl: Y=X+60-120*np.random.uniform()

adultXX-7ALT.pkl: Y=X*(.5+1*np.random.uniform())




***The two python files in this directory are necessary to recreate these datasets, along with the simulator. If used to replace the files of the same name in the simulator from GitHub, they allow noisy carb values to be used for bolus calculations and add delays/missing boluses. We are not the authors of this code but made simple modifications only.
